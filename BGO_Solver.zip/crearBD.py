from BD.sqlite import BD

bd = BD()

bd.construirTablas()